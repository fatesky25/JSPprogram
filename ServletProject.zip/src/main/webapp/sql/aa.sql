select * from TEMPMEMBER

create table aa (
no number(5) not null,
name varchar2(20)
);