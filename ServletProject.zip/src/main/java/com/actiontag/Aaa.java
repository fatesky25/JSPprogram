package com.actiontag;

public class Aaa {

	public static void main(String[] args) {
		Customer customer = new Customer();
		//customer.set
		
	}
	
	
}
